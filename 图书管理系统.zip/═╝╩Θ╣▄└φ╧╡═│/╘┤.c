#include<stdio.h>
#include"library.h"

int main(void) {

	Library_Init();
	//BOOK_REND_READ();
}